#include <stdlib.h>
#include <stdio.h>
#include <math.h>


const int  PAGES = 4096;

int main()
{
	unsigned long pageNum = 0, offset = 0, startAddr = 0;
	unsigned long input;
	printf("Enter Number:");
	scanf("%Lu", &input);
	pageNum = (unsigned long)floor(input / PAGES);
	offset = input % PAGES;
	startAddr = pageNum * PAGES;
	printf("Page %Lu, Offset %Lu, Starting Address %Lu\n", pageNum, offset, startAddr);


}